//Moe htet paing
import java.util.Scanner;
import java.io.*;
public class zaid {
    public static void main(String[] args) throws IOException {
        int choice, ID, Zip, Courseid, enrollmentid,displaystudent, displaycourse, Year;
        String Firstname, Lastname, Address, Coursename, Coursedescription, filename, Semester, Grade;
        Scanner input = new Scanner(System.in);


        do {

            System.out.println("1. Add Student");
            System.out.println("2. Add Course");
            System.out.println("3. Display Student");
            System.out.println("4. Display Course");
            System.out.println("5. Add Enrollment");
            System.out.println("6 Exit");
            System.out.println("Please choose");
            choice = input.nextInt();
            input.nextLine();

            switch (choice) {
                case 1: {
                    FileWriter studentwriter = new FileWriter("Student.txt", true);
                    PrintWriter outputfile = new PrintWriter(studentwriter);


                    System.out.println("Please enter student ID");
                    ID = input.nextInt();
                    input.nextLine();

                    System.out.println("Please enter student First Name");
                    Firstname = input.nextLine();

                    System.out.println("Please enter student Last Name");
                    Lastname = input.nextLine();

                    System.out.println("Please enter student Address");
                    Address = input.nextLine();

                    System.out.println("Please enter student Zip");
                    Zip = input.nextInt();

                    outputfile.println(ID);
                    outputfile.println(Firstname);
                    outputfile.println(Lastname);
                    outputfile.println(Address);
                    outputfile.println(Zip);

                    outputfile.close();
                    System.out.println("Data Added");

                    break;
                }
                case 2: {

                    FileWriter Coursewriter = new FileWriter("Course.txt", true);
                    PrintWriter Coursefile = new PrintWriter(Coursewriter);


                    System.out.println("Please enter Course ID");
                    Courseid = input.nextInt();
                    input.nextLine();


                    System.out.println("Please enter Course Name");
                    Coursename = input.nextLine();

                    System.out.println("Please enter Course Description");
                    Coursedescription = input.nextLine();

                    Coursefile.println(Courseid);
                    Coursefile.println(Coursename);
                    Coursefile.println(Coursedescription);

                    Coursefile.close();
                    System.out.println("Data Added");

                    break;
                }
                case 3: {
                    File file = new File("Student.txt");
                    Scanner inputfile = new Scanner(file);

                    System.out.println("Please enter the student Id number to display");
                    int todiplayid = input.nextInt();
                    input.nextLine();


                    while (inputfile.hasNext()) {
                        int checkid = inputfile.nextInt();
                        for (int i = 0; i < 5; i++) {
                            String Line = inputfile.nextLine();

                            if (todiplayid == checkid) {
                                System.out.println("ID is " + checkid);
                                for (int j = 0; j < 4; j++) {
                                    System.out.println(inputfile.nextLine());
                                }
                                if (todiplayid == checkid) {
                                    break;
                                }
                                //System.exit(0);
                            }
                        }
                    }
                    inputfile.close();
                    break;
                }
                case 4: {
                    File displayfile = new File("Course.txt");
                    Scanner todisplaycourse = new Scanner(displayfile);

                    System.out.println("Please enter Course ID that want to display");
                    int selectcourse = input.nextInt();
                    input.nextLine();

                    while (todisplaycourse.hasNext()) {
                        int checkkid = todisplaycourse.nextInt();

                        for (int i = 0; i < 3; i++) {
                            String Line = todisplaycourse.nextLine();

                            if (selectcourse == checkkid) {
                                System.out.println("ID is " + checkkid);
                                for (int l = 0; l < 2; l++) {
                                    System.out.println(todisplaycourse.nextLine());
                                }
                                if (selectcourse == checkkid) {
                                    break;
                                }
                            }
                        }
                    }
                    todisplaycourse.close();
                    break;
                }
                case 5: {
                    FileWriter enrollmentwriter = new FileWriter("Enrollment.txt", true);
                    PrintWriter enrollmentoutputfile = new PrintWriter(enrollmentwriter);


                    File sfile = new File("Student.txt");
                    File cfile = new File("Course.txt");
                    File efile=new File("Enrollment.txt");

                    System.out.println("Enter Enrollment ID");
                    enrollmentid = input.nextInt();
                    Boolean enrollmentcheck = Enrollmentid(enrollmentid, efile);

                    if (enrollmentcheck)
                    {
                        System.out.println("Enrollment ID exist");
                        break;
                    }

                    System.out.println("Enter Student ID");
                    int studentid = input.nextInt();
                    input.nextLine();

                    boolean studentexist = studentcheckID(studentid, sfile);

                    if (!studentexist)
                    {
                        System.out.println("Student ID doesnt exist");
                        break;
                    }

                    System.out.println("Enter Course ID");
                    int courseid = input.nextInt();
                    input.nextLine();

                    boolean coursexist = Courseexist(courseid, cfile);

                    if (!coursexist) {
                        System.out.println("Course ID doesnt exist");
                        break;
                    }
                    System.out.println("Enter Semester to enroll");
                    Semester = input.nextLine();

                    System.out.println("Enter Year");
                    Year = input.nextInt();
                    input.nextLine();

                    System.out.println("Enter Grade ");
                    Grade = input.nextLine();

                    enrollmentoutputfile.println(enrollmentid);
                    enrollmentoutputfile.println(Semester);
                    enrollmentoutputfile.println(Year);
                    enrollmentoutputfile.println(Grade);

                    enrollmentoutputfile.close();
                    System.out.println("Data Added");

                }
            }
        }
        while (choice != 6);
        System.exit(0);
    }

    public static boolean studentcheckID(int id, File sfile) throws IOException {
        Scanner filecheck = new Scanner(sfile);
        boolean Studentexist = false;

        int studentcheckid = id;

        while (filecheck.hasNext()) {
            int sidcheck = filecheck.nextInt();
            for (int i = 0; i < 5; i++) {
                String Line = filecheck.nextLine();

                if (sidcheck == studentcheckid) {
                    System.out.println("It exist");
                    Studentexist = true;
                    break;
                }
            }
            if (Studentexist)
                break;
        }

        return Studentexist;
    }

    public static boolean Courseexist(int id, File csfile) throws IOException {
        Scanner csfilecheck = new Scanner(csfile);
        int courseidcheck = id;

        Boolean Courseexist = false;

        while (csfilecheck.hasNext()) {
            int csidcheck = csfilecheck.nextInt();
            for (int i = 0; i < 3; i++) {
                String Line = csfilecheck.nextLine();

                if (csidcheck == courseidcheck) {
                    System.out.println("It exist");
                    Courseexist = true;
                    break;
                }
            }
            if (Courseexist) {
                break;
            }
        }
        return Courseexist;
    }

    public static boolean Enrollmentid(int id, File efile) throws IOException {
        Scanner efilecheck = new Scanner(efile);
        int eidcheck = id;
        Boolean Enrollmentexist = false;

        while (efilecheck.hasNext()) {
            int enrollmentid = efilecheck.nextInt();
            for (int i = 0; i < 4; i++) {
                String Line = efilecheck.nextLine();

                if (eidcheck == enrollmentid) {
                    //System.out.println("It exist");
                    Enrollmentexist = true;
                    break;
                }
            }
            if (Enrollmentexist)
            {
                break;
            }
        }
        return Enrollmentexist;
    }
}

