//Moe htet paing
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.StringTokenizer;
//import java.

public class test2 {
    public static void main(String args[]) throws IOException
    {
        Scanner input=new Scanner(System.in);

        PoliceOfficer policinfo=new PoliceOfficer();
         policinfo.policofficerinfo();


        ParkedCar park=new ParkedCar();
        ParkingMeter pm=new ParkingMeter();


        PoliceOfficer police=new PoliceOfficer(park,pm);
        ParkingTicket parkingticket=new ParkingTicket(police,park,pm);

    }
}
class ParkedCar
{
    String carmake,carmodel,carcolor,licencenum;
    int minutepark;
    Scanner input=new Scanner(System.in);
    ParkedCar()
    {
        System.out.println("Enter the car's make");
        carmake=input.nextLine();

        System.out.println("Enter the car's model");
        carmodel=input.nextLine();

        System.out.println("Enter the car's color");
        carcolor=input.nextLine();

        System.out.println("Enter the car's liscense number");
        licencenum=input.nextLine();

        System.out.println("Enter Minutes on car");
        minutepark=input.nextInt();

        while (minutepark<=0)
        {
            System.out.println("Invalid Entry. Please try again.");
            minutepark=input.nextInt();
        }
    }
}
class ParkingMeter
{
    Scanner input=new Scanner(System.in);
    int min;
    ParkingMeter()
    {
        System.out.println("Enter the number of minutes purchased on the meter");
        min=input.nextInt();

        while(min<=0)
        {
            System.out.println("Invalid Entry. Please try again.");
            min=input.nextInt();
        }

    }
}
class ParkingTicket
{
    double fine;
    PoliceOfficer p1=new PoliceOfficer();
    ParkingTicket(PoliceOfficer police,ParkedCar park,ParkingMeter pm)
    {
        System.out.println("Ticket data:");
        System.out.println();
        System.out.println("Make: "+park.carmake);
        System.out.println();
        System.out.println("Model: "+park.carmodel);
        System.out.println();
        System.out.println("Color: "+park.carcolor);
        System.out.println();
        System.out.println("Licence Number: "+park.licencenum);
        System.out.println();
        System.out.println("Officer Name: "+p1.officer);
        System.out.println();
        System.out.println("Badge Number: "+p1.badge);
        System.out.println();
        int extramin=pm.min-60;

        if(pm.min<60)
        {
            fine=25.0;
        }
        else if(extramin> pm.min)
        {
            int additionalHours = (extramin + 59) / 60;
            fine += additionalHours * 10.0;
        }

        System.out.println("Fine: "+fine);


    }
}
class PoliceOfficer
{
    static String officer;
    static int badge;

    Scanner input=new Scanner(System.in);

    void policofficerinfo()
    {
        System.out.println("Enter the officer's name");
         officer = input.nextLine();

        System.out.println("Enter officer's badge number");
         badge = input.nextInt();

    }
    String officer()
    {
        return officer;
    }

    int badge()
    {
        return badge;
    }

    PoliceOfficer()
    {

    }

    PoliceOfficer(ParkedCar park,ParkingMeter pm)
    {
        int minuteparchase=pm.min;
        int minoncar=park.minutepark;

        if(minuteparchase<minoncar)
        {
            System.out.println("Car parking time has expired.");
            System.out.println();

        }
        else
        {
            System.out.println("The car parking minutes are valid");
            System.exit(0);
        }
    }

}
